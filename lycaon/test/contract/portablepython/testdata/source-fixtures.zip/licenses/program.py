import yaml, csv, io
data = yaml.safe_load(open('config/repos.yaml'))
rows=[]
for r in data['repos']:
    if r['split'] != 'holdout': continue
    for path, digest in r['license_files'].items():
        rows.append([r['name'], r['language'], r['spdx'], r['commit'], path, digest])
with open('holdout_repos.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['repository','language','spdx','commit','license_path','expected_sha256']); w.writerows(rows)
print(open('holdout_repos.csv').read())
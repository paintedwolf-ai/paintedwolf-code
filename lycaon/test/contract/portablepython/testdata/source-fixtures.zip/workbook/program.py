import yaml
from openpyxl import Workbook, load_workbook
from collections import Counter

with open("config/repos.yaml") as f:
    data = yaml.safe_load(f)
repos = data["repos"]

wb = Workbook()
ws = wb.active
ws.title = "Repositories"
ws.append(["Name", "Language", "Split", "License", "Pinned Commit"])
for r in repos:
    ws.append([r["name"], r["language"], r["split"], r["spdx"], r["commit"]])
ws.freeze_panes = "A2"
for col, w in zip("ABCDE", (14, 12, 10, 22, 44)):
    ws.column_dimensions[col].width = w

counts = Counter((r["split"], r["language"]) for r in repos)
splits = sorted({s for s, _ in counts})
langs = sorted({l for _, l in counts})
ws2 = wb.create_sheet("Counts by Split and Language")
ws2.append(["Split"] + langs + ["Total"])
for s in splits:
    row = [s] + [counts.get((s, l), 0) for l in langs]
    row.append(sum(row[1:]))
    ws2.append(row)
tot = ["Total"] + [sum(counts.get((s, l), 0) for s in splits) for l in langs]
tot.append(sum(tot[1:]))
ws2.append(tot)
ws2.freeze_panes = "B2"

wb.save("repositories.xlsx")

# verify reopen
wb2 = load_workbook("repositories.xlsx")
assert wb2.sheetnames == ["Repositories", "Counts by Split and Language"]
r1 = wb2["Repositories"]
assert r1.freeze_panes == "A2"
assert r1.max_row == len(repos) + 1
r2 = wb2["Counts by Split and Language"]
assert r2.freeze_panes == "B2"
print("sheets:", wb2.sheetnames)
print("repos sheet rows:", r1.max_row, "cols:", r1.max_column, "freeze:", r1.freeze_panes)
for row in r1.iter_rows(min_row=2, values_only=True):
    print(" ", row)
print("counts sheet:")
for row in r2.iter_rows(values_only=True):
    print(" ", row)
print("reopen verification: OK")
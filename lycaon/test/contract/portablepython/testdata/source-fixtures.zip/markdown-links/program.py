import os, re, csv, urllib.parse
md_links = re.compile(r'\[[^\]]*\]\(([^)]+)\)')
rows=[]
for root,dirs,files in os.walk('.'):
    dirs[:] = [d for d in dirs if d not in ('.git','.paintedwolf','node_modules')]
    for f in files:
        if not f.endswith('.md'): continue
        p=os.path.relpath(os.path.join(root,f),'.')
        for m in md_links.finditer(open(p).read()):
            t=m.group(1).strip()
            if t.startswith('<') and t.endswith('>'): t=t[1:-1]
            if not t or t.startswith(('http://','https://','mailto:','#')) : continue
            t=t.split('#')[0]
            if not t: continue
            target=os.path.normpath(os.path.join(os.path.dirname(p), urllib.parse.unquote(t)))
            rows.append((p, t, os.path.isfile(target)))
with open('links.csv','w',newline='') as fh:
    w=csv.writer(fh); w.writerow(['source','target','target_exists']); w.writerows(rows)
print(rows)
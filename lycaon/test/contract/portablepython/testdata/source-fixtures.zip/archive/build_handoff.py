#!/usr/bin/env python3
"""Build the release handoff ZIP reproducibly.

Usage: python3 build_handoff.py [OUTPUT.zip]
Produces a ZIP containing every file under releases/ at member name
releases/<filename>, plus a SHA256SUMS at the ZIP root covering those
member names. Fixed metadata makes byte-identical output for identical inputs.
"""
import hashlib
import sys
import zipfile
from pathlib import Path

RELEASES_DIR = Path(__file__).resolve().parent / "releases"
FIXED_DATE_TIME = (1980, 1, 1, 0, 0, 0)  # earliest storable ZIP timestamp

def build(output: Path) -> None:
    anchors = sorted(p for p in RELEASES_DIR.iterdir() if p.is_file())
    if not anchors:
        raise SystemExit("no anchor files found in releases/")

    # Deterministic member payload + checksums
    entries = []
    for path in anchors:
        data = path.read_bytes()
        name = f"releases/{path.name}"
        entries.append((name, data, hashlib.sha256(data).hexdigest()))

    sums = "".join(f"{h}  {n}\n" for n, _d, h in entries).encode()

    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data, _h in entries:
            zi = zipfile.ZipInfo(name, date_time=FIXED_DATE_TIME)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            zf.writestr(zi, data)
        zi = zipfile.ZipInfo("SHA256SUMS", date_time=FIXED_DATE_TIME)
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16
        zf.writestr(zi, sums)

    print(f"wrote {output} ({output.stat().st_size} bytes, "
          f"{len(entries)} anchors + SHA256SUMS)")

if __name__ == "__main__":
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "release-handoff.zip")
    build(out)

import tomllib, re, csv, pathlib

def lock_versions(path):
    d = tomllib.load(open(path,'rb'))
    return {p['name']: p['version'] for p in d['package'] if 'version' in p}

def req_versions(path):
    out = {}
    for line in open(path):
        line = line.strip()
        if not line or line.startswith('#'): continue
        m = re.match(r'^([A-Za-z0-9_.-]+)\[?[A-Za-z0-9_,.\-]*\]?==(.+)$', line)
        if m: out[m.group(1)] = m.group(2)
    return out

rows = []
for src, fn in [('uv.lock', lock_versions), ('train-host/requirements-cuda.txt', req_versions)]:
    before = fn(f'before/{src}')
    after = fn(f'after/{src}')
    for pkg in sorted(set(before)|set(after)):
        o, n = before.get(pkg), after.get(pkg)
        if o != n:
            rows.append([src, pkg, o or '', n or ''])

with open('dependency-changes.csv','w',newline='') as f:
    w = csv.writer(f)
    w.writerow(['source','package','old_version','new_version'])
    w.writerows(rows)

# pin agreement between the two lists, within each tree
for tree in ['before','after']:
    lock = {k.lower().replace('_','-'): v for k,v in lock_versions(f'{tree}/uv.lock').items()}
    req = {k.lower().replace('_','-'): v for k,v in req_versions(f'{tree}/train-host/requirements-cuda.txt').items()}
    shared = set(lock)&set(req)
    print(tree, 'shared:', {p:(lock[p],req[p]) for p in sorted(shared)})
    print(tree, 'disagreements:', [p for p in shared if lock[p]!=req[p]])

print('--- rows ---')
for r in rows: print(r)

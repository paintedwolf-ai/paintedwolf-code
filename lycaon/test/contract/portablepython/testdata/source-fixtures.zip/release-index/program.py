import json, glob, collections
anchors = []
for p in sorted(glob.glob('releases/*.json')):
    with open(p) as f:
        a = json.load(f)
    anchors.append(a)
by_ver = collections.OrderedDict()
for a in anchors:
    v = a['version']
    e = by_ver.setdefault(v, {})
    e[a['kind']] = {'sha256sums': a['sha256sums'], **({'holdout': a['holdout']} if 'holdout' in a else {})}
index = {'schema': 'pw-decide-release-index/1', 'versions': by_ver}
with open('release-index.json', 'w') as f:
    json.dump(index, f, indent=2)
    f.write('\n')
both = [v for v, e in by_ver.items() if 'dataset' in e and 'heads' in e]
print('both:', both)
print(json.dumps(index, indent=2))